"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Mod {
    postDBLoad(container) {
        // Log load
        const logger = container.resolve("WinstonLogger");
        logger.log("Doing some wizard shit...", "cyan");
        // get database from server
        const databaseServer = container.resolve("DatabaseServer");
        // Get all the in-memory json found in /assets/database
        const tables = databaseServer.getTables();
        const items = tables.templates.items;
        const securecontainer = [
            {
                "name": "Secure Container Alpha",
                "itemID": "544a11ac4bdc2d470e8b456a",
                "removeFilters": true
            },
            {
                "name": "Secure Container Beta",
                "itemID": "5857a8b324597729ab0a0e7d",
                "removeFilters": true
            },
            {
                "name": "Secure Container Gamma",
                "itemID": "5857a8bc2459772bad15db29",
                "removeFilters": true
            },
            {
                "name": "Secure Container Epsilon",
                "itemID": "59db794186f77448bc595262",
                "removeFilters": true
            }
        ];
        // Loop through and update back pack stats in game
        let i = 0;
        while (i < securecontainer.length) {
            // Remove filters if requested to
            if (securecontainer[i].removeFilters === true) {
                items[securecontainer[i].itemID]._props.Grids[0]._props.filters = [];
            }
            i++;
        }
        logger.log("Abbra kadabbra, bye bye restrictions", "cyan");
    }
}
module.exports = { mod: new Mod() };
